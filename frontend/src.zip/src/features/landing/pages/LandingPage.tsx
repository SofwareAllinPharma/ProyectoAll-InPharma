import About from "../components/About";
import Central from "../components/Central";

export default function LandingPage() {
  return (
    <>
      <Central />
      <About />
    </>
  );
}