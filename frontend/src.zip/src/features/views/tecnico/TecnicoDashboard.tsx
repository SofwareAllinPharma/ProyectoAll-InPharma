export default function TecnicoDashboard() {
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-bold">Panel Técnico</h1>
      <p className="opacity-80 text-sm">Acá irán los accesos rápidos a operaciones técnicas.</p>
    </div>
  );
}
